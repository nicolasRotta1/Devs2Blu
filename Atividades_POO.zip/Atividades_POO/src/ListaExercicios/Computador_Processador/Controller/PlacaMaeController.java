package ListaExercicios.Computador_Processador.Controller;

public class PlacaMaeController {
}
