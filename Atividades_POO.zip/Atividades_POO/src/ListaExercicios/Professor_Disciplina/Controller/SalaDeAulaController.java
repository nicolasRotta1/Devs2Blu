package ListaExercicios.Professor_Disciplina.Controller;

public class SalaDeAulaController {
}
