package ListaExercicios.Carro_Proprietario.Controller;

public class ProprietarioController {
}
