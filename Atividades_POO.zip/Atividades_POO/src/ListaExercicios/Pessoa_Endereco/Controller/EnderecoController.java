package ListaExercicios.Pessoa_Endereco.Controller;

public class EnderecoController {
}
