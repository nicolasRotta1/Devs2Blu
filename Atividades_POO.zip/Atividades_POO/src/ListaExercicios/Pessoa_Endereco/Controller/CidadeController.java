package ListaExercicios.Pessoa_Endereco.Controller;

import ListaExercicios.Pessoa_Endereco.Models.Cidade;

public class CidadeController {


}
