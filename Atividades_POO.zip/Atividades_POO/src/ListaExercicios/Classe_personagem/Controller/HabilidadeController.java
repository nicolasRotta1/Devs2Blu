package ListaExercicios.Classe_personagem.Controller;

public class HabilidadeController {
}
